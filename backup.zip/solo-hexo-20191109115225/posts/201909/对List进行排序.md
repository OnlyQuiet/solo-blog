title: 对List进行排序
date: '2019-09-26 20:08:59'
updated: '2019-09-26 20:08:59'
tags: [code, 随笔]
permalink: /articles/2019/09/26/1569499739338.html
---
![](https://img.hacpai.com/bing/20180901.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
 /** 
     * @param <T>
     * @param targetList 目标排序List 
     * @param sortField 排序字段(实体类属性名) 
     * @param sortMode 排序方式（asc or  desc） 
     * @param flag 按数字方式排序
     */  
    public static <T> void sortList(List<T> targetList, final String sortField, final String sortMode,final boolean flag) {
        Collections.sort(targetList, (Comparator) (obj1, obj2) -> {   
            int retVal = 0;  
            try {  
                //首字母转大写  
                String newStr=sortField.substring(0, 1).toUpperCase()+sortField.replaceFirst("\\w","");   
                String methodStr="get"+newStr;  
                  
                Method method1 = ((T)obj1).getClass().getMethod(methodStr);  
                Method method2 = ((T)obj2).getClass().getMethod(methodStr);  
                Object tmpObj1 = method1.invoke((obj1));
                Object tmpObj2 = method2.invoke((obj2));
                String s1 = "";
                String s2 = "";
                if(tmpObj1!=null){
                      s1 = tmpObj1.toString();
                }else{
                    s1 = ""+Integer.MIN_VALUE;
                }
                if(tmpObj2!=null){
                     s2 = tmpObj2.toString();
                }else{
                    s2 = ""+Integer.MIN_VALUE;
                }
                if(flag){
                    BigDecimal b1 = NumberUtils.stringToBigDecimal(s1);
                    BigDecimal b2 = NumberUtils.stringToBigDecimal(s2);
                    if (sortMode != null && "desc".equals(sortMode)) {  
			// 倒序
                        retVal = b2.compareTo(b1);   
                    } else {  
			// 正序
                        retVal = b1.compareTo(b2);   
                    }  
                }else{
                    if (sortMode != null && "desc".equals(sortMode)) {  
			// 倒序
                        retVal = s2.compareTo(s1);   
                    } else {  
			 // 正序
                        retVal = s1.compareTo(s2); 
                    }  
                }
            } catch (Exception e) {  
                throw new RuntimeException();  
            }  
            return retVal;  
        });  
    }  
```
