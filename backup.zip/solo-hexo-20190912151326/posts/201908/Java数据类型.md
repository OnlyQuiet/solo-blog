title: Java数据类型
date: '2019-08-23 22:56:58'
updated: '2019-08-23 23:45:35'
tags: [Java数据类型]
permalink: /articles/2019/08/23/1566572218385.html
---
![](https://img.hacpai.com/bing/20180929.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

Java语言规范中提供了两种数据类型：基本数据类型和复核数据类型。
 1. 基本数据类型：***byte***、***short***、***int***、***long***、***float***、***double***、***char***、***boolean***。
 2. 复核数据类型：除了基本类型以外的数据类型统称为复核数据类型。

# 一、基本数据类型
## 1、整型
整型，即整数类型，对应数学中的整数，是用来存放整数的数据类型。
|内存空间|类型|名称|范围
|--|--|--|--|
| 8bit |byte|字节型|-2^7^ ~ 2^7^-1|
| 16bit |short|短整型|-2^15^ ~ 2^15^-1|
| 32bit |int|整型|-2^31^ ~ 2^31^-1|
| 64bit |long|长整型|-2^63^ ~ 2^63^-1|
## 2、浮点型
浮点型，即包含小数部分的数字，可以近似理解为带有小数点的数值。Java中有两种浮点数据类型可以用来表示这类数据，他们是float（单精度）和double（双精度）。
|内存空间|类型|名称|范围
|--|--|--|--|
| 32bit |float|单精度型|1.4E-45 ~ 3.4E+38|
| 64bit |double|双精度型|4.9E-324 ~ 1.7E+308|
==在Java中，具有小数的数值默认是double，如果要强制指定某数值为float，需要在对相应数字后面加上f，例如：0.00f。==
```java
float f = 1.555f;
```
==float参与运算，会存在精度丢失，在不允许存在误差的情况下，需慎重使用。（在生产中与金额相关的计算，一般使用BigDecimal）==
```java
public class FloatTest {
    public static void main(String[] args) {
        float f = 0.0f;
        System.out.println("初始值：" + f);
        for (int i = 0; i < 10; i++) {
            f += 0.01f;
            System.out.println("第" + (i+1) + "次循环结果：" + f);
        }
    }
}
```
运行结果：
![精度丢失演示](https://img-blog.csdnimg.cn/20190126181501100.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ExODYwMjMyMDI3Ng==,size_16,color_FFFFFF,t_70)
## 3、字符型
字符类型（char）表示Unicode编码方案中的字符。
|转义字符|描述  |
|--|--|
| \ddd |1~3位八进制数所表示的字符（ddd）,范围为：'\000' ~ '\377' |
| \uxxxx |1~4位十六进制数所表示的字符（ddd）,范围为：0 ~ 65535 |
| \\' |单引号字符 |
| \\\ |反斜杠字符|
| \r |回车 |
| \n |换行 |
| \f |走纸换页|
| \t |横向跳格 |
| \b |退格 |
Unicode编码表：https://www.cnblogs.com/csguo/p/7401874.html 
## 4、布尔型
布尔类型（boolean）表示一个特殊的数据类型，它只有两个值：true（真）和false（假）。主要用于逻辑条件判断。
|类型|名称|范围|
|--|--|--|
| boolean |布尔型|true（真）、false（假）|

# 二、类型转换
## 1、自动类型转换
数据类型之间的自动转换，如下图所示：
![数据类型之间的自动转换](https://img-blog.csdnimg.cn/20190126012535374.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ExODYwMjMyMDI3Ng==,size_16,color_FFFFFF,t_70)
实线箭头的转换方向，表示无精度损失的转换方向；虚线箭头的转换方向，表示有可能会存在精度损失的转换方向。
==***byte***、***short***、***int***、***long***、***float***、***double***、***char***、***boolean*** ***这样排序有利于记忆***==

例子：
```java
public class DataAutoChange {
    public static void main(String[] args) {
        // 整型
        int i = 512551155;
        System.out.println("整型：int i = " + i);
        // 双精度
        double d = i;
        System.out.println("双精度：double d = " + d);
        // 单精度
        float f = i;
        System.out.println("单精度：float f = " + f);
    }
}
```
运行结果：
![运行结果](https://img-blog.csdnimg.cn/20190126174736981.png)
## 2、强制类型转换
强制类型转换，有可能会有精度损失。那为什么会有精度的损失呢？这个跟基本类型所能表示的范围有关，范围小的类型转换为范围大的，不会有精度损失，而范围大的转换为范围小的就有可能会存在精度损失。就好比大海和水杯，你把水杯里的水到进大海，大海不会溢出，而你把大海的水倒进水杯里，水杯装不装得下就不一定了，这取决于舀海水的瓢。
将高级数据类型向低级数据类型转换（强制把大海的水往杯子里倒）的语法如下：
`目标类型 变量名 = (目标类型) 变量名；`
```java
float f = (float) d;
```
我们在原有代码上修改如下：
```java
public class DataAutoChange {
    public static void main(String[] args) {
        // 整型
        int i = 512551155;
        System.out.println("整型：int i = " + i);
        // 双精度
        double d = i;
        System.out.println("双精度：double d = " + d);
        // 双精度强制转换为单精度
        float f = (float) d;
        System.out.println("强制转换：float f = " + f);
    }
}
```
运行结果：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190126183424565.png)
