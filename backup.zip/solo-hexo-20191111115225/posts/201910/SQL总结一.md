title: SQL总结（一）
date: '2019-10-25 14:09:54'
updated: '2019-10-25 14:09:54'
tags: [sql]
permalink: /articles/2019/10/25/1571983794198.html
---
# 查询某张表的所有数据
```
SELECT * FROM emp;
```
# 筛选行
```
SELECT * FROM emp WHERE deptno = 1;
```
WHERE 后面是查询条件，可以接and、or、>=、<=等。如果想查询满足多个条件的数据，可以这样做

```
SELECT * FROM emp WHERE deptno = 1 AND (sal < 2000 or comm is null);
```

**注意：and、or等逻辑条件有优先级，为了保证查询条件的正确性，应该加上(),括号里面的条件总是最高优先级。**

# 筛选列
```
select ename,deptno,sal from emp;
```
# 为列创建别名
```
select sal as salary  from emp; 
```
其中【as】可以省略
```
select sal salary  from emp; 
```
**注意：WHERE 子句里面不能直接使用别名**
```
-- 这句话会报错
select sal as salary  from emp WHERE salary = 1000 ; 
```
**正确的使用方式如下**
```
select *  from ( select sal as salary, comm as commission  from emp ) temp where salary < 5000
```
# 自定义列名
## DB2、Oracle、PostgreSQL → ||。 
```
select ename||' WORKS AS A '||job as msg from emp where deptno=10
```
## MySQL  → CONCAT 
```
select concat(ename, ' WORKS AS A ',job) as msg from emp  where deptno=10
```
## SQL Server → +
```
select ename + ' WORKS AS A ' + job as msg from emp where deptno=10
```
# case when then end
```
select ename,sal, 
case when sal <= 2000 then 'UNDERPAID' 
when sal >= 4000 then 'OVERPAID' 
else 'OK' 
end as status 
from emp
```
# 限定返回行数
## DB2 使用 FETCH FIRST 子句。 
```
select * from emp fetch first 5 rows only 
```
## MySQL 和 PostgreSQL 使用 LIMIT 子句。 
```
select *  from emp limit 5 
```
## Oracle 通过在 WHERE 子句中限制 ROWNUM 的值来获得指定行数的结果集。 
```
select * from emp where rownum <= 5 
```
**注意：rownum的特殊性，永远取不到rownum = 5的数据**
## SQL Server 使用 TOP 关键字限定返回行数。 
```
select top 5 *  from emp
```
# 查找Null值
```
-- 为空
select * from emp where comm is null
```
```
-- 不为空
select * from emp where comm is not null
```
# 把Null值转换为实际值
```
select coalesce(comm,0)  from emp
```
**注意：COALESCE正好适用于所有数据库，当然Oracle中，你也可以使用decode**
# 模糊查询
```
 select ename, job from emp where deptno in (10,20) and (ename like '%I%' or job like '%ER')
```

