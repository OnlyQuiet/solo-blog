title: 《Java多线程编程核心技术》学习笔记（1）
date: '2019-08-19 20:30:08'
updated: '2019-08-19 20:30:08'
tags: [JAVA, 多线程, 学习笔记]
permalink: /articles/2019/08/19/1566217808198.html
---
![](https://img.hacpai.com/bing/20190528.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 一、实现多线程的编程方式
（1）继承Thread类

```java
public class MyThread extends Thread {
   @Override
   public void run() {
      super.run();
      System.out.println("MyThread");
   }
}
```

```java
public class Run {

   public static void main(String[] args) {
      MyThread mythread = new MyThread();
      mythread.start();
      System.out.println("运行结束！");
   }

}
```

（2）实现Runnable接口

```java
public class MyRunnable implements Runnable {
   @Override
   public void run() {
      System.out.println("运行中!");
   }
}
```

```java
public class Run {

   public static void main(String[] args) {
      Runnable runnable=new MyRunnable();
      Thread thread=new Thread(runnable);
      thread.start();
      System.out.println("运行结束!");
   }

}
```
# 二、实例变量与线程安全
i - - 的操作分为3步：
* 取得原有i值。
* 计算i-1。
* 对i进行赋值。

如果有多个线程同时访问，那么会存在非线程安全的问题。这个时候可以用到关键字：**synchronized** 
```java
public class MyThread extends Thread {

   private int count=5;
   
   @Override
   synchronized public void run() {
      super.run();
         count--;
         System.out.println("由 "+this.currentThread().getName()+" 计算，count="+count);
   }
}
```

```java
public class Run {
   public static void main(String[] args) {
      MyThread mythread=new MyThread();

      Thread a=new Thread(mythread,"A");
      Thread b=new Thread(mythread,"B");
      Thread c=new Thread(mythread,"C");
      Thread d=new Thread(mythread,"D");
      Thread e=new Thread(mythread,"E");
      a.start();
      b.start();
      c.start();
      d.start();
      e.start();
   }
}
```
# 三、currentThread()方法
用于返回代码段正在被哪个线程调用的信息。

```java
public class MyThread extends Thread {

   public MyThread() {
       System.out.println("构造方法的打印：" 
+ Thread.currentThread().getName());
   }

   @Override
   public void run() {
       System.out.println("run方法的打印：" 
+ Thread.currentThread().getName());
   }

}
```


```java

public class Run1 {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName());
    }
}
```


```java
public class Run2 {
    public static void main(String[] args) {
        MyThread mythread = new MyThread();
        // mythread.start();
        mythread.run();
    }
}
```

运行结果：
|    | Run2   | Run2   | 
|:----:|:----:|:----:|
| 构造方法的打印：   | main   | main   | 
| run方法的打印：   | Thread-0   | main   | 

# 四、isAlive()方法
判断当前线程是否处于活动状态
# 五、sleep()方法
方法sleep()的作用是在指定的毫秒数内让当前“正在执行的线程”休眠（暂停执行）。这个正在执行的线程是指this.currentThread()返回的线程。
# 六、getId()方法
取得线程的唯一标识。
# 七、停止线程
## 1）停止不了的线程 - interrupt()
调用interrupt()方法仅仅是在当前线程中打了一个停止的标记，并不是真正的停止了线程。
## 2）判断线程是否停止状态
this.interrupted()：测试当前线程是否已经是中断状态，执行后具有将状态标志清除为false的功能。
this.isInterrupted()：测试线程Tread对象是否已经是中断状态，但不清除状态标志。
## 3）能停止的线程——异常法
在线程中用for语句来判断一下线程是否是停止状态，如果是停止状态，则后面的代码不再运行即可。
关键代码：for循环中break。
## 4）在沉睡中停止
sleep()
## 5）能停止的线程——暴力停止
~~stop()~~

## 6）能停止的线程——return
# 八、暂停线程
暂停线程意味着此线程还可以恢复运行。在java多线程中，可以使用~~suspend()~~ 方法暂停线程，使用~~resume()~~ 方法恢复线程的执行。
## 1）~~suspend~~与~~resume~~的缺点——独占
## 2）~~suspend~~与~~resume~~的缺点——不同步
# 九、yield方法
yield()是放弃当前的cpu资源，将它让给其他任务去占用cpu执行时间。但是放弃的时间不确定，有可能刚刚放弃，就又获得了cpu时间片。
# 十、线程的优先级
setPriority()方法可以设置线程的优先级。
## 1）线程的优先级具有继承性
## 2）线程的优先级具有规则性
cpu尽量将执行资源让给优先级比较高的线程，但不代表高优先级的线程全部先执行完。
## 3）线程的优先级高的运行的快
# 十一、守护线程
守护线程的作用是为其他线程的运行提供便利的服务，最典型的是GC（垃圾回收器）。
```java
public class MyThread extends Thread {
   private int i = 0;

   @Override
   public void run() {
      try {
         while (true) {
            i++;
            System.out.println("i=" + (i));
            Thread.sleep(1000);
         }
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }
}
```

```java
public class Run {
   public static void main(String[] args) {
      try {
         MyThread thread = new MyThread();
         thread.setDaemon(true);
         thread.start();
         Thread.sleep(5000);
         System.out.println("我离开thread对象也不再打印了，也就是停止了！");
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }
}
```



## 







