title: LeetCode刷题日记
date: '2019-09-17 16:24:19'
updated: '2019-10-06 11:38:22'
tags: [LeetCode算法]
permalink: /articles/2019/09/17/1568708659091.html
---
![](https://img.hacpai.com/bing/20180327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### [804. 唯一摩尔斯密码词](https://leetcode-cn.com/problems/unique-morse-code-words/)
题目描述：
国际摩尔斯密码定义一种标准编码方式，将每个字母对应于一个由一系列点和短线组成的字符串， 比如: "a" 对应 ".-", "b" 对应 "-...", "c" 对应 "-.-.", 等等。

为了方便，所有26个英文字母对应摩尔斯密码表如下：

[".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."]
给定一个单词列表，每个单词可以写成每个字母对应摩尔斯密码的组合。例如，"cab" 可以写成 "-.-..--..."，(即 "-.-." + "-..." + ".-"字符串的结合)。我们将这样一个连接过程称作单词翻译。

返回我们可以获得所有词不同单词翻译的数量。

例如:
输入: words = ["gin", "zen", "gig", "msg"]
输出: 2
解释: 
各单词翻译如下:
"gin" -> "--...-."
"zen" -> "--...-."
"gig" -> "--...--."
"msg" -> "--...--."

共有 2 种不同翻译, "--...-." 和 "--...--.".
 

注意:

单词列表words 的长度不会超过 100。
每个单词 words[i]的长度范围为 [1, 12]。
每个单词 words[i]只包含小写字母。

题解：
```
	private static String[] map = {
			".-",
			"-...",
			"-.-.",
			"-..",
			".",
			"..-.",
			"--.",
			"....",
			"..",
			".---",
			"-.-",
			".-..",
			"--",
			"-.",
			"---",
			".--.",
			"--.-",
			".-.",
			"...",
			"-",
			"..-",
			"...-",
			".--",
			"-..-",
			"-.--",
			"--.."
	};
	public int uniqueMorseRepresentations(String[] words) {
		if (words == null) return 0;
		HashSet<String> set = new HashSet<String>();
		for (String s : words) {
			StringBuilder sb = new StringBuilder();
			for (char c : s.toCharArray()) {
				sb.append(map[c - 'a']);
			}
			set.add(sb.toString());
		}
		return set.size();
	}
```
#### [832. 翻转图像](https://leetcode-cn.com/problems/flipping-an-image/)
题目描述：
给定一个二进制矩阵 A，我们想先水平翻转图像，然后反转图像并返回结果。

水平翻转图片就是将图片的每一行都进行翻转，即逆序。例如，水平翻转 [1, 1, 0] 的结果是 [0, 1, 1]。

反转图片的意思是图片中的 0 全部被 1 替换， 1 全部被 0 替换。例如，反转 [0, 1, 1] 的结果是 [1, 0, 0]。

示例 1:

输入: [[1,1,0],[1,0,1],[0,0,0]]
输出: [[1,0,0],[0,1,0],[1,1,1]]
解释: 首先翻转每一行: [[0,1,1],[1,0,1],[0,0,0]]；
     然后反转图片: [[1,0,0],[0,1,0],[1,1,1]]
示例 2:

输入: [[1,1,0,0],[1,0,0,1],[0,1,1,1],[1,0,1,0]]
输出: [[1,1,0,0],[0,1,1,0],[0,0,0,1],[1,0,1,0]]
解释: 首先翻转每一行: [[0,0,1,1],[1,0,0,1],[1,1,1,0],[0,1,0,1]]；
     然后反转图片: [[1,1,0,0],[0,1,1,0],[0,0,0,1],[1,0,1,0]]
说明:

1 <= A.length = A[0].length <= 20
0 <= A[i][j] <= 1

题解：
```
	public int[][] flipAndInvertImage(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			int start = 0, end = A[i].length - 1;
			while (start < end) {
				if (A[i][start] != A[i][end]) {
					start++;
					end--;
				} else {
					A[i][start] = A[i][start] == 1 ? 0 : 1;
					A[i][end] = A[i][end] == 1 ? 0 : 1;
					start++;
					end--;
				}
			}
			if (start == end) {
				A[i][start] = A[i][start] == 1 ? 0 : 1;
			}
		}
		return A;
	}
```
#### [461. 汉明距离](https://leetcode-cn.com/problems/hamming-distance/)
题目描述：
两个整数之间的汉明距离指的是这两个数字对应二进制位不同的位置的数目。

给出两个整数 x 和 y，计算它们之间的汉明距离。

注意：
0 ≤ x, y < 231.

示例:

输入: x = 1, y = 4

输出: 2

解释:
1   (0 0 0 1)
4   (0 1 0 0)

上面的箭头指出了对应二进制位不同的位置。
题解：
```
	public int hammingDistance(int x, int y) {
		//bitCount 数出整数二进制下 1 的个数
		//1^0 = 1 ,0^1 =1 ,0^0 = 0 ,1^1 = 0
		return Integer.bitCount(x^y);
	}
```
#### [226. 翻转二叉树](https://leetcode-cn.com/problems/invert-binary-tree/)
题目描述：
翻转一棵二叉树。

示例：

输入：

```
     4
   /   \
  2     7
 / \   / \
1   3 6   9
```
输出：

```
     4
   /   \
  7     2
 / \   / \
9   6 3   1
```
备注:
这个问题是受到 Max Howell 的 原问题 启发的 ：

谷歌：我们90％的工程师使用您编写的软件(Homebrew)，但是您却无法在面试时在白板上写出翻转二叉树这道题，这太糟糕了。
题解：
```
	// [4,2,7,1,3,6,9]
	  public class TreeNode {
	      int val;
	      TreeNode left;
	      TreeNode right;
	      TreeNode(int x) { val = x; }
	  }


		public TreeNode invertTree(TreeNode root) {
			if (root == null) {
				return null;
			}
			TreeNode right = invertTree(root.right);
			TreeNode left = invertTree(root.left);
			root.left = right;
			root.right = left;
			return root;
		}
```
#### [657. 机器人能否返回原点](https://leetcode-cn.com/problems/robot-return-to-origin/)
在二维平面上，有一个机器人从原点 (0, 0) 开始。给出它的移动顺序，判断这个机器人在完成移动后是否在 (0, 0) 处结束。

移动顺序由字符串表示。字符 move[i] 表示其第 i 次移动。机器人的有效动作有 R（右），L（左），U（上）和 D（下）。如果机器人在完成所有动作后返回原点，则返回 true。否则，返回 false。

注意：机器人“面朝”的方向无关紧要。 “R” 将始终使机器人向右移动一次，“L” 将始终向左移动等。此外，假设每次移动机器人的移动幅度相同。

 

示例 1:

输入: "UD"
输出: true
解释：机器人向上移动一次，然后向下移动一次。所有动作都具有相同的幅度，因此它最终回到它开始的原点。因此，我们返回 true。
示例 2:

输入: "LL"
输出: false
解释：机器人向左移动两次。它最终位于原点的左侧，距原点有两次 “移动” 的距离。我们返回 false，因为它在移动结束时没有返回原点。

题解：
```
	// R、L、U、D
    public boolean judgeCircle(String moves) {
		char[] chars = moves.toCharArray();
		int R = 0;
		int L = 0;
		int U = 0;
		int D = 0;
		for (char c : chars){
			switch (c){
				case 'R' :
					R++;
					break;
				case 'L' :
					L++;
					break;
				case 'U' :
					U++;
					break;
				case 'D' :
					D++;
					break;
			}
		}
		if (R == L && D==U){
			return true;
		}
		return false;
    }
```
#### [1051. 高度检查器](https://leetcode-cn.com/problems/height-checker/)
题目描述：
学校在拍年度纪念照时，一般要求学生按照 非递减 的高度顺序排列。

请你返回至少有多少个学生没有站在正确位置数量。该人数指的是：能让所有学生以 非递减 高度排列的必要移动人数。

 

示例：

输入：[1,1,4,2,1,3]
输出：3
解释：
高度为 4、3 和最后一个 1 的学生，没有站在正确的位置。
 

提示：

1 <= heights.length <= 100
1 <= heights[i] <= 100

题解：
```
public int heightChecker(int[] heights) {
		// 值的范围是1 <= heights[i] <= 100，因此需要1,2,3,...,99,100，共101个桶
		int[] arr = new int[101];
		// 遍历数组heights，计算每个桶中有多少个元素，也就是数组heights中有多少个1，多少个2，。。。，多少个100
		// 将这101个桶中的元素，一个一个桶地取出来，元素就是有序的
		for (int height : heights) {
			arr[height]++;
		}

		int count = 0;
		for (int i = 1, j = 0; i < arr.length; i++) {
			// arr[i]，i就是桶中存放的元素的值，arr[i]是元素的个数
			// arr[i]-- 就是每次取出一个，一直取到没有元素，成为空桶
			while (arr[i]-- > 0) {
				// 从桶中取出元素时，元素的排列顺序就是非递减的，然后与heights中的元素比较，如果不同，计算器就加1
				if (heights[j++] != i) count++;
			}
		}
		return count;
	}
```
#### [977. 有序数组的平方](https://leetcode-cn.com/problems/squares-of-a-sorted-array/)
示例 1：

输入：[-4,-1,0,3,10]
输出：[0,1,9,16,100]
示例 2：

输入：[-7,-3,2,3,11]
输出：[4,9,9,49,121]
 

提示：

1 <= A.length <= 10000
-10000 <= A[i] <= 10000
A 已按非递减顺序排序。

```
public int[] sortedSquares(int[] A) {
        int N = A.length;
		int[] ans = new int[N];
		for (int i = 0; i < N; ++i){
			ans[i] = A[i] * A[i];
		}
		Arrays.sort(ans);
		return ans;
    }
```
#### [942. 增减字符串匹配](https://leetcode-cn.com/problems/di-string-match/)
题目描述：
给定只含 "I"（增大）或 "D"（减小）的字符串 S ，令 N = S.length。

返回 [0, 1, ..., N] 的任意排列 A 使得对于所有 i = 0, ..., N-1，都有：

如果 S[i] == "I"，那么 A[i] < A[i+1]
如果 S[i] == "D"，那么 A[i] > A[i+1]
 

示例 1：

输出："IDID"
输出：[0,4,1,3,2]
示例 2：

输出："III"
输出：[0,1,2,3]
示例 3：

输出："DDI"
输出：[3,2,0,1]
 

提示：

1 <= S.length <= 1000
S 只包含字符 "I" 或 "D"。

题解：
```
	/**
	 * 解题思路：双指针
	 * @param S 输入的字符串
	 * @return 输出的数组
	 */
	public int[] diStringMatch(String S) {
		// 输入的字符串长度
		int sLen = S.length();
		// 输出的数组
		int[] arr = new int[sLen + 1];
		// 最大值指针
		int max = sLen;
		// 最小值指针
		int min = 0;
		for(int i = 0 ; i < sLen; i++) {
			// 如果指令为D——》减小，那么当前数组为最大值，且最大值加1，
			if('D' == S.charAt(i)) {
				arr[i] = max--;
			} else {
				// 如果指令为I——》增加，那么当前数组为最小值，且最小值加1
				arr[i] = min++;
			}
		}
		// 数组最后一位的大小应该等于最大值
		arr[sLen] = max;
		return arr;
	}
```
#### [728. 自除数](https://leetcode-cn.com/problems/self-dividing-numbers/)
题目描述：
自除数 是指可以被它包含的每一位数除尽的数。

例如，128 是一个自除数，因为 128 % 1 == 0，128 % 2 == 0，128 % 8 == 0。

还有，自除数不允许包含 0 。

给定上边界和下边界数字，输出一个列表，列表的元素是边界（含边界）内所有的自除数。

示例 1：

输入： 
上边界left = 1, 下边界right = 22
输出： [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 15, 22]
注意：

每个输入参数的边界满足 1 <= left <= right <= 10000。

题解：
```
	public List<Integer> selfDividingNumbers(int left, int right) {
		List<Integer>list = new ArrayList<Integer>();
		for(int i=left;i<=right;i++){
			if(isDividingNumber(i)){
				list.add(i);
			}
		}
		return list;
	}
	private boolean isDividingNumber(int num){
		// 定义中间变量，最后一位
		int temp = 0;
		// 入参
		int n = num;
		// 如果入参大于0
		while(num>0){
			// 获取最后一位
			temp = num%10;
			// 如果最后一位为0，或者不能被整除
			if(temp==0||n%temp!=0){
				return false;
			}
			// 去掉最后一位
			num = num/10;
		}
		return true;
	}
```
#### [237. 删除链表中的节点](https://leetcode-cn.com/problems/delete-node-in-a-linked-list/)
请编写一个函数，使其可以删除某个链表中给定的（非末尾）节点，你将只被给定要求被删除的节点。

现有一个链表 -- head = [4,5,1,9]，它可以表示为:

示例 1:

输入: head = [4,5,1,9], node = 5
输出: [4,1,9]
解释: 给定你链表中值为 5 的第二个节点，那么在调用了你的函数之后，该链表应变为 4 -> 1 -> 9.
示例 2:

输入: head = [4,5,1,9], node = 1
输出: [4,5,9]
解释: 给定你链表中值为 1 的第三个节点，那么在调用了你的函数之后，该链表应变为 4 -> 5 -> 9.
 

说明:

链表至少包含两个节点。
链表中所有节点的值都是唯一的。
给定的节点为非末尾节点并且一定是链表中的一个有效节点。
不要从你的函数中返回任何结果。

题解：
```
/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
class Solution {
    public void deleteNode(ListNode node) {
        node.val = node.next.val;
        node.next = node.next.next;
    }
}
```
