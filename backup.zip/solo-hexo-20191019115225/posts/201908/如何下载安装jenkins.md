title: 如何下载安装jenkins
date: '2019-08-23 22:37:15'
updated: '2019-08-23 22:37:15'
tags: [jenkins]
permalink: /articles/2019/08/23/1566571035303.html
---
一、下载：
jenkins 支持Docker、yum、msi 等安装，在这里推荐大家直接选择下载他对应的WAR包进行安装。
官网地址：https://jenkins.io/download/
csdn下载：https://download.csdn.net/download/a18602320276/10930946

二、启动：
下载完成之后直接可通过 jar -jar 命令启动
（1）java -jar jenkins.war --httpPort=8080
（2）也可以将其放至到servlet容器（tomcat\jetty\jboss）中直接启动，无需过多的配置，一切插件化这是jenkins 比较优秀的设计。

三、配置：下载完成之后进入启动页(http://127.0.0.1:8080/) 会有一个 验证过程，验证码存储在 ${user_home}\.jenkins\secrets\initialAdminPassword 中，接着就是进入安装插件页，选择默认即可，这个过程稍长。
