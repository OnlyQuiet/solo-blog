title: easyUI弹出框，兼容点击红叉触发事件
date: '2019-09-10 10:37:32'
updated: '2019-09-10 10:38:22'
tags: [前端easyUI]
permalink: /articles/2019/09/10/1568083052297.html
---
easyUI弹出框，右上方红叉不触发事件的解决方案：因为alter继承于window，所以可以绑定事件到window。
```
var msgAlter = $.messager.alert('警告', '活动价必须小于原价', 'warning');
            // 兼容点击红叉触发事件
            msgAlter.window({modal:true,onBeforeClose:function() {
                    $('#plusPrice').numberbox('clear');
                    $('#discountPrice').numberbox('clear');
                }});
```
