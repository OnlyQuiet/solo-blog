title: ' IDEA实用手册'
date: '2019-10-01 11:16:46'
updated: '2019-10-01 11:16:46'
tags: [IDEA]
permalink: /articles/2019/10/01/1569899806790.html
---
# 一. IDEA简介
## 1. 简介

![图片](https://uploader.shimo.im/f/vd8X2v2JHXkTYz9s!thumbnail)

IDEA 全称IntelliJ IDEA，是[java语言](https://baike.baidu.com/item/java%E8%AF%AD%E8%A8%80 \t _blank)开发的集成环境。
IDEA是JetBrains公司的产品。
JetBrains官网 : [https://www.jetbrains.com/](https://www.jetbrains.com/idea/download/ \l section=windows) 
IntelliJ在业界被公认为最好的java开发工具之一，尤其在智能代码助手、代码自动提示、重构、[J2EE](https://baike.baidu.com/item/J2EE \t _blank)支持、[Ant](https://baike.baidu.com/item/Ant/16001870 \t _blank)、JUnit、[CVS](https://baike.baidu.com/item/CVS \t _blank)整合、代码审查方面。

了解：JetBrains公司开发的所有工具。
  ![图片](https://uploader.shimo.im/f/KXQKcSd6jec1KkRI!thumbnail) 

## 2. 下载

下载地址：[https://www.jetbrains.com/idea/download/#section=windows](https://www.jetbrains.com/idea/download/ \l section=windows)
 ![图片](https://uploader.shimo.im/f/wQwW9jH6CcgUmrD7!thumbnail)
版本简介：IDEA分商业版和社区版。商业版是收费的，功能比较完善。社区版是免费的，功能稍弱。

## 3. 安装 (Windows环境下)
### 1. 双击exe文件

![图片](https://uploader.shimo.im/f/P7mKi1MNXnsUVtN6!thumbnail)
### 2. 选择安装的目录

![图片](https://uploader.shimo.im/f/JK5f4aCfeYgBWBI0!thumbnail)
### 3. 选择是否生成快捷方式和建立文件关联

 ![图片](https://uploader.shimo.im/f/YRVVaNQwG6Iqoedz!thumbnail)
  上图标记1中32-bit launcher 支持JDK1.7  ；64-bit lanucher 最低需要JDK1.8版本。
上图标记 2 表示关联 Java、Groovy和Kotlin 文件，建议不要勾选，正常我们会在 Windows 的文件系统上打开这类文件都是为了快速查阅文件里面的内容，如果用 IntelliJ IDEA 关联上之后，由于 IntelliJ IDEA 打开速度缓慢，这并不能方便我们查看。 建议在 Windows 系统上关联此类文件可以用 EmEditor、Notepad++ 这类轻便的编辑器。
### 4. 完成安装

![图片](https://uploader.shimo.im/f/pQKFtr2xsK0a2YrO!thumbnail)
# 二. IDEA的配置
## 1. 首次运行配置
### 1. 设置是否导入之前的配置

如果是升级安装,可以导入之前的配置.如果是首次安装,直接选择第二个选项.
![图片](https://uploader.shimo.im/f/r5FRUCPmuL49dBFj!thumbnail)
### 2. 设置授权

根据自己的实际情况选择授权方式.
![图片](https://uploader.shimo.im/f/9xgN0N2Sd44uEHUk!thumbnail)
如果只是试用,请按照下图方式选择
![图片](https://uploader.shimo.im/f/DNousHttFwUJK4SQ!thumbnail)

### 3. 设置样式

![图片](https://uploader.shimo.im/f/p2ziAfXCUwE55hIu!thumbnail)

### 4. 设置需要的功能

![图片](https://uploader.shimo.im/f/6NQYTkD2XiQd43Kl!thumbnail)
所有的功能默认都是开启,如果不需要,可以点击Disable禁用对应的功能,设置后,点击右下角的Next

### 5. 选择下载插件

![图片](https://uploader.shimo.im/f/xp7V02WZNHoYBiQJ!thumbnail)
在当前页面有官方推荐的插件,如果有需要可以点击Install下载安装.
推荐安装IDE Features Tranier,该插件可以帮助我们快速了解IDEA的使用.
设置后点击右下角的Start.
配置成功后,可以看到启动页面
![图片](https://uploader.shimo.im/f/nKtcRH8xFgwfi38R!thumbnail)


## 2. 基础设置
### 1. 进入全局设置

![图片](https://uploader.shimo.im/f/gEJsOnvNZO0qaGW4!thumbnail)
### 2. 更改主题

 ![图片](https://uploader.shimo.im/f/NCzk2Cf43cYjxLhj!thumbnail)
### 3. 修改主题字体

 ![图片](https://uploader.shimo.im/f/1kNik6gKed8VAKMv!thumbnail)

该操作并不推荐,如果要修改,请务必选择中文字体,否则会导致中文无法正常显示
### 4. 修改代码编辑区字体

 
![图片](https://uploader.shimo.im/f/FUusyhtt9NE2XDmc!thumbnail)
可以设置两个字体.当第一字体无法使用时,可以使用第二字体.

### 5. 修改控制台字体

![图片](https://uploader.shimo.im/f/tjLquNiAeTcT43sL!thumbnail)

图中3处修改控制台字体
图中4处修改控制台字体


### 6. 文件编码的设置

   ![图片](https://uploader.shimo.im/f/wOamDA7ujqAdX9jk!thumbnail)

图中4处建议勾选,如果没有勾选属性文件中的中文,会被转为ASCII码

### 7. 设置可以使用Ctrl + 鼠标滚轮更改字体大小

![图片](https://uploader.shimo.im/f/ZTBWwSiu9r0FcTCZ!thumbnail)

### 8. 设置显示行号和方法分割线

![图片](https://uploader.shimo.im/f/YFpL2TESkuospGbH!thumbnail)

### 9. 设置格式化代码时将多余的空行转为一行

![图片](https://uploader.shimo.im/f/IAKbTmD3u9oaYT5u!thumbnail)

### 10. 设置代码提示

![图片](https://uploader.shimo.im/f/yAUkPjq9Mmodk8bQ!thumbnail)

IDEA默认的代码提示是完全匹配大小写,这样我们在写代码的时候,由于类名都是大写开始,就会导致无法提示,不够方便, 因此我们要按照图中所示更改为NONE

### 11. 设置自动导包

![图片](https://uploader.shimo.im/f/gwG1iUV9mkcG8X4E!thumbnail)

当我们复制代码时,IDEA不会自动导入对应类的包,需要手动导包,这样不够方便, 因此我们要按照图中所示进行更改

### 12. 设置鼠标悬浮事件

![图片](https://uploader.shimo.im/f/Snol1YoWT3ICHVHA!thumbnail)

该功能的作用时, 当鼠标悬浮在类上时,显示对应的源码.如果需要,按照图中所示进行设置

## 3. 安装插件

IDEA可以安装第三方的插件,进行功能增强.添加步骤如下:

![图片](https://uploader.shimo.im/f/O1JQv0N8UDckpISi!thumbnail)

图中1 : 安装官方插件
图中2 : 安装第三方插件
图中3 : 从本地磁盘离线安装插件

![图片](https://uploader.shimo.im/f/71AYPcsBh5k8XNrC!thumbnail)
安装官方插件和第三方插件时,可以使用上图中的搜索框进行搜索,找到对应插件后,使用右侧的安装按钮进行安装,安装结束后重启IDEA即可生效
## 4. JDK环境的配置
### 1. 进入JDK配置界面

![图片](https://uploader.shimo.im/f/e0g4FQlCH6AsNwNK!thumbnail)
### 2. 创建JDK环境

![图片](https://uploader.shimo.im/f/LyZ33d87O3AOVK6X!thumbnail)
### 3. 选择本地JDK的安装位置

![图片](https://uploader.shimo.im/f/K2wkQecFmE8OAFx9!thumbnail)
### 4. 保存配置

![图片](https://uploader.shimo.im/f/0qplD1I26UYPklz3!thumbnail)
点击右下角的Apply后,再点击OK保存配置

# 三. 创建JavaSE工程
## 1. 第一步

![图片](https://uploader.shimo.im/f/FcE76vY56mcEYtlb!thumbnail)
## 2. 第二步

![图片](https://uploader.shimo.im/f/SzcxNfcKOGgJf1Aq!thumbnail)

## 3. 第三步

开启工具栏和工具按钮
![图片](https://uploader.shimo.im/f/bCK4sScSZq8g4ck0!thumbnail)
## 4. 第四步

创建Java类
![图片](https://uploader.shimo.im/f/Q39RTxHYC4MuGAAM!thumbnail)
## 5. 第五步

![图片](https://uploader.shimo.im/f/bJ5citLqpp48cwwx!thumbnail)
## 6. 第六步

运行代码.右键选中图中按钮
![图片](https://uploader.shimo.im/f/UvoGBYpDC6QNjuyI!thumbnail)
选择Run
![图片](https://uploader.shimo.im/f/hvpGiGg2cHsPwxGt!thumbnail)


# 四. 配置IDEA的JVM内存值

IDEA默认配置的JVM内存值比较低,如果硬件配置较高,可以修改该设置.
该设置需要在工程界面进行.
该操作仅建议内存8G以上,64位操作系统进行. 
![图片](https://uploader.shimo.im/f/I150M1bTC8A1vM2K!thumbnail)
![图片](https://uploader.shimo.im/f/6GR85GcLV18gKub6!thumbnail)

上图中的数值请根据机身实际情况进行修改

# 五. 全局设置的两种方式
## 1. 在启动界面进入全局设置

![图片](https://uploader.shimo.im/f/miKnC7tn4iU2ydA9!thumbnail)
## 2. 在编码界面进入全局设置

![图片](https://uploader.shimo.im/f/Ueotn5eFzl0sAzyt!thumbnail)

## 3. 本项目配置

![图片](https://uploader.shimo.im/f/VpOul5vG7WQFIqi5!thumbnail)
上面的这种设置仅对本项目生效,不会对其他项目生效.请特别注意!!!

# 六. IDEA的断点调试
## 1. 打断点

![图片](https://uploader.shimo.im/f/g2rC6eBUOg8uQX4P!thumbnail)
在行号的右侧点击鼠标左键,出现红色圆形图标,说明已经被打上断点
## 2. Debug模式运行

![图片](https://uploader.shimo.im/f/hDWVFO6c1Ncr7cEZ!thumbnail)
运行代码时,选择Debug模式

## 3. 断点调试常用快捷键

 ![图片](https://uploader.shimo.im/f/XOwQDPaTkE8lmsYj!thumbnail)
 比较常用的有：F7跳到下一步；F8跳到下一个断点；F9回复程序运行，如果该断点下面代码还有断点则停止在下一个断点上；Shift+F7:进入断点执行处的方法
 

  ### 1.  快捷键对应的图标

 ![图片](https://uploader.shimo.im/f/5YcNGhfVtcAP6ZtE!thumbnail)

 
## 4. 查看变量的值

选中变量，在变量上悬停两秒（其实在当前行后面也会显示出执行结果）
   ![图片](https://uploader.shimo.im/f/tHNBHD7x0fgUixbk!thumbnail)
   
 

# 7. 创建JavaWeb项目
## 1. 创建工程
### 1. 第一步

![图片](https://uploader.shimo.im/f/dgQREsxTnz472ULV!thumbnail)
### 2. 第二步

![图片](https://uploader.shimo.im/f/tdbCxlyVRrISmrxv!thumbnail)
### 3. 第三步

如果要修改JavaEE版本,请根据下图所示进行修改
![图片](https://uploader.shimo.im/f/kVzFusDMsPciNDWn!thumbnail)
### 4. 第四步

![图片](https://uploader.shimo.im/f/rqFGd0UUsM0smpNC!thumbnail)


## 2. 发布工程
### 1. 第一步

![图片](https://uploader.shimo.im/f/spWDvrnZV4InglD2!thumbnail)
### 2. 第二步

![图片](https://uploader.shimo.im/f/bTJhUL4rv8Esrwat!thumbnail)
### 3. 第三步

点击下图中按钮, 添加Tomcat环境
![图片](https://uploader.shimo.im/f/L6wrfTz1BMY7hCbI!thumbnail)

### 4. 第四步

点击下图中按钮,指定本地Tomcat的安装位置
![图片](https://uploader.shimo.im/f/9YHnHCI8TYEa5tMm!thumbnail)
![图片](https://uploader.shimo.im/f/zdKeh8qHQ1Aiv15V!thumbnail)
![图片](https://uploader.shimo.im/f/ayXvpYcxr5wunJc6!thumbnail)
### 5. 第五步

点击右下角的fix按钮, 选择以war exploded结尾的选项
![图片](https://uploader.shimo.im/f/MoPv6yKIb28U8Bna!thumbnail)
### 6. 第六步

IDEA在部署项目时, 不会为项目生成路径.
例如本项目名为javaweb, 有一个页面为index.html, 按照常规, 访问路径应为 [http://l](http://localhost:8080/javaweb/index.html)ocalhost:8080/javaweb/index.html . 但是在IDEA中部署后, 访问路径为 [http://localhost:8080/index.html](http://localhost:8080/index.html) . 如果要修改为第一种访问路径的话,需要手动按照下图所示进行修改 .
![图片](https://uploader.shimo.im/f/h6nn14VI8I4QDcp9!thumbnail)
### 7. 第七步

按照下图所示进行修改. 如果没有按照下图进行配置, 在我们每次修改页面后,都要重启服务器才能看到最新的效果.. 修改之后, 无需重启服务器, 即可看到最新的效果.
![图片](https://uploader.shimo.im/f/qVCeVXY6Uv0fgjxz!thumbnail)
### 8. 第八步

点击下图按钮1启动服务器.点击按钮2以Debug模式启动服务器

![图片](https://uploader.shimo.im/f/4FHbILuAhBgA07pg!thumbnail)
## 3. 添加第三方Jar
### 1. 第一步

在WEB-INF文件夹中新建文件夹lib

![图片](https://uploader.shimo.im/f/EGUtJJzydoYFRUdm!thumbnail)

![图片](https://uploader.shimo.im/f/69lsfQtbMroZ7HKQ!thumbnail)

### 2. 第二步

选择下图中的按钮
![图片](https://uploader.shimo.im/f/0nAC5eMSt4EGwsHc!thumbnail)

### 3. 第三步

按照下图所示进行选择

![图片](https://uploader.shimo.im/f/DgtjsMj1Nnc8XS54!thumbnail)

### 4. 第四步

选择刚刚创建的lib目录,并点击OK

![图片](https://uploader.shimo.im/f/woaum2IHp8cIWiax!thumbnail)

### 5. 第五步

选择Jar Directory, 并点击OK, 之后再次点击OK

![图片](https://uploader.shimo.im/f/3T9FXDatA0gzioFv!thumbnail)
![图片](https://uploader.shimo.im/f/XNtJzWdYhn8fyF9c.png!thumbnail)

### 6. 第六步

按下图所示进行配置. 配置成功后, 即可使用lib目录存放的第三方Jar

![图片](https://uploader.shimo.im/f/fkwCQZcrWmw1pFaP!thumbnail)

## 6. 创建Servlet
### 1. 第一步

![图片](https://uploader.shimo.im/f/IzB7m7LvOLwWg1xh!thumbnail)
### 2. 第二步

![图片](https://uploader.shimo.im/f/wi717bj4vH4W6tFW!thumbnail)
### 3. 第三步

指定Servlet的访问路径
![图片](https://uploader.shimo.im/f/moAGsm7oyd0Pcr8P!thumbnail)
### 4. 第四步

由于新创建的Web项目, 没有Tomcat环境, 所以创建的Servlet会发生导包错误,如下图所示 :

![图片](https://uploader.shimo.im/f/sTyZFaHOREsoqOpg!thumbnail)
因此我们需要手动指定Tomcat环境, 选中下图中的按钮
![图片](https://uploader.shimo.im/f/m0sw5oeGDCYYENmq!thumbnail)
### 5. 第五步

![图片](https://uploader.shimo.im/f/JHpHiIHyKbUtgInb!thumbnail)
### 6. 第六步

![图片](https://uploader.shimo.im/f/GuKs2rYJGtIC8r07!thumbnail)
### 7. 第七步

![图片](https://uploader.shimo.im/f/GLRUIajSVEUNBvpu!thumbnail)

# 八. 配置Maven的全局设置

使用之前需要提前安装好Maven
## 1. 第一步

![图片](https://uploader.shimo.im/f/WxA1lnN9nf8Miq3G!thumbnail)
## 2. 第二步

![图片](https://uploader.shimo.im/f/hqpOd2U6wZU2T8d6!thumbnail)

# 九. 使用Maven创建JavaSE项目
## 1. 第一步

![图片](https://uploader.shimo.im/f/y9Xk0TFE7cIHfHIy!thumbnail)
## 2. 第二步

![图片](https://uploader.shimo.im/f/1sOcf7n0xbMeYP5A!thumbnail)
在IDEA中,我们常用三种骨架
org.apache.maven.archetypes:maven-archetype-quickstart  :  打包方式为jar
org.apache.maven.archetypes:maven-archetype-webapp  :  打包方式为war
org.apache.maven.archetypes:maven-archetype-site  :  打包方式为pom

## 3. 第三步

![图片](https://uploader.shimo.im/f/9oewdORbuBQ6EEa3!thumbnail)
## 4. 第四步

![图片](https://uploader.shimo.im/f/x7fgSvZTQLcrmzK8!thumbnail)
## 5. 第五步

![图片](https://uploader.shimo.im/f/uj9LShUMO2osBepV!thumbnail)
## 6. 第六步

等待创建完成
![图片](https://uploader.shimo.im/f/8DB43buZGps7sw7G!thumbnail)
## 7. 第七步

点击右下角的Enable Auto-Import
![图片](https://uploader.shimo.im/f/KTwwDJk5j5oSppKT!thumbnail)
至此项目就创建完成. 如果需要添加依赖,修改pom.xml即可
# 十. Maven快捷菜单的介绍

在打开工具菜单以后, 可以在右侧找到Maven的快捷操作菜单. 如图所示

![图片](https://uploader.shimo.im/f/0hpyqSLdmC0KZM0d!thumbnail)
点击以后, 即可展开所有的菜单项

![图片](https://uploader.shimo.im/f/M7eiNBpGyKAZxcPe!thumbnail)

# 十一. 使用Maven创建JavaWeb项目
## 1. 第一步

![图片](https://uploader.shimo.im/f/hwnRASBGohcJdy5B!thumbnail)
## 2. 第二步

![图片](https://uploader.shimo.im/f/o31Hzhdua1MMDg1t!thumbnail)
## 3. 第三步

![图片](https://uploader.shimo.im/f/EdOkayD5lOMXcXtv!thumbnail)
## 4. 第四步

![图片](https://uploader.shimo.im/f/bI3IoewJEX4oQSJa!thumbnail)
## 5. 第五步

![图片](https://uploader.shimo.im/f/q2tlqQd57LAGhsrO!thumbnail)
## 6. 第六步

点击右下角的Enable Auto-Import
![图片](https://uploader.shimo.im/f/E8u7d9sc8OctJPhN!thumbnail)
## 7. 第七步

默认情况下, IDEA在使用Maven创建JavaWeb工程的时候, 并没有创建保存Java文件的目录.所以需要我们自己手动创建.
![图片](https://uploader.shimo.im/f/m6NGkB6LHFcYqjZQ!thumbnail)
## 8. 第八步

指定文件夹名字, 一般为java
![图片](https://uploader.shimo.im/f/OiouyaOfYfIWRIJK!thumbnail)
## 9. 第九步

设置文件夹为源文件文件夹
![图片](https://uploader.shimo.im/f/q7D3MoNf9dkeqik4!thumbnail)
至此项目创建完成, 如果需要使用Tomcat发布, 按照前面的介绍进行配置即可. 
下面介绍使用Maven的Tomcat插件发布的方式
## 10. 第十步

在pom文件中配置Tomcat插件
```
    <build>
        <plugins>
            <plugin>

                <groupId>org.apache.tomcat.maven</groupId>
                <artifactId>tomcat7-maven-plugin</artifactId>
                <version>2.2</version>
                <configuration>
                    <port>9999</port>
                    <path>/</path>
                </configuration>
            </plugin>
        </plugins>
</build>
```

## 11. 第十一步

从右侧工具菜单中找到对应的命令, 双击运行
![图片](https://uploader.shimo.im/f/Jdc4czRAE0wGnGNj!thumbnail)


## 12. 使用Maven创建聚合项目

![图片](https://uploader.shimo.im/f/uhBtjRcli7slcrT8!thumbnail)

本聚合项目将按照上图结构进行创建.

### 1. 第一步

创建itheima_mall 工程
![图片](https://uploader.shimo.im/f/NQuzFUw650QFaZTH!thumbnail)
![图片](https://uploader.shimo.im/f/RFP0urPWyQkfVyZE!thumbnail)
后续操作和前面介绍的创建Maven工程步骤一样, 在此不再赘述.

### 2. 第二步

右键选中itheima_mall工程, 创建itheima_portal工程

![图片](https://uploader.shimo.im/f/DwkfbxqLd6A2TIZ3!thumbnail)
![图片](https://uploader.shimo.im/f/Isn5ordO3gIq92an!thumbnail)

在本示例中, itheima_mall工程只用来管理版本, 因此我们在创建itheima_portal工程的时候需要做一个修改

![图片](https://uploader.shimo.im/f/MvrEfonQZIQkfuEQ!thumbnail)
按照上图进行修改后, itheima_portal将会是一个独立的工程, 而不是itheima_mall的子模块


在创建itheima_portal的时候, 如果不希望将工程保存在itheima_mall的目录中, 我们需要做如下修改
![图片](https://uploader.shimo.im/f/zZWnwVNeP8EGDuAH!thumbnail)

后续操作和前面介绍的创建Maven工程步骤一样, 在此不再赘述.


### 3. 第三步

右键选中itheima_portal工程, 创建itheima_portal_dao模块
![图片](https://uploader.shimo.im/f/mLTiSSlRNMsjhIuJ!thumbnail)

骨架类型选择org.apache.maven.archetypes:maven-archetype-quickstart

![图片](https://uploader.shimo.im/f/7L9G8OyHqQUJn8en!thumbnail)

在指定保存路径的时候, 必须按照下图所示进行修改. 否则新创建的子模块pom文件会覆盖itheima_portal的pom文件

![图片](https://uploader.shimo.im/f/p3xJLnxoIbEX1dld!thumbnail)
后续操作和前面介绍的创建Maven工程步骤一样, 在此不再赘述.
### 4. 第四步

右键选中itheima_portal工程, 创建itheima_portal_service模块
![图片](https://uploader.shimo.im/f/xqgE1O5B0Xkh4JdD!thumbnail)

骨架类型选择org.apache.maven.archetypes:maven-archetype-quickstart

![图片](https://uploader.shimo.im/f/PamL8nZEfeolpk6S!thumbnail)

在指定保存路径的时候, 必须按照下图所示进行修改. 否则新创建的子模块pom文件会覆盖itheima_portal的pom文件

![图片](https://uploader.shimo.im/f/PCUZIgwhoj81LiHX!thumbnail)
后续操作和前面介绍的创建Maven工程步骤一样, 在此不再赘述.

### 5. 第五步

在itheima_portal_servie模块的pom文件中增加依赖

```
        <dependency>
            <groupId>com.itheima</groupId>
            <artifactId>itheima_portal_dao</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>
```
### 6. 第六步

右键选中itheima_portal工程, 创建itheima_portal_service模块
![图片](https://uploader.shimo.im/f/PyglAdSdp90kUcLz!thumbnail)

骨架类型选择org.apache.maven.archetypes:maven-archetype-webapp
![图片](https://uploader.shimo.im/f/uEvDsBEM6B4M4pHQ!thumbnail)
在指定保存路径的时候, 必须按照下图所示进行修改. 否则新创建的子模块pom文件会覆盖itheima_portal的pom文件

![图片](https://uploader.shimo.im/f/cx7AggdEQKgCz0QM!thumbnail)
后续操作和前面介绍的创建Maven工程步骤一样, 在此不再赘述.

### 7. 第七步

在itheima_portal_web模块的pom文件中增加依赖
```
        <dependency>
            <groupId>com.itheima</groupId>
            <artifactId>itheima_portal_service</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>
```

itheima_back工程的创建, 和itheima_portal工程的创建一样, 请参考上述步骤
# 十三. 使用SVN管理代码

在进行本操作前, 请准备好SVN环境
## 1. 第一步

![图片](https://uploader.shimo.im/f/49i8XvbK7XYqUYir!thumbnail)
## 2. 第二步

指定服务器地址
![图片](https://uploader.shimo.im/f/7kWN2jcz39IaR1jq!thumbnail)
## 3. 第三步

填写相应信息后, 提交代码
![图片](https://uploader.shimo.im/f/KQkaIijG7UYvOfqG!thumbnail)
## 4. 第四步

指定SVN版本, 选择默认即可

![图片](https://uploader.shimo.im/f/lkNF2yVXPC09fA1H!thumbnail)
## 5. 第五步

输入访问服务器的用户名和密码, 点击OK
![图片](https://uploader.shimo.im/f/PkGcxJl1MQELHunk!thumbnail)
## 6. 第六步

设置忽略
![图片](https://uploader.shimo.im/f/Se3bhvPApjIDHfUf!thumbnail)

![图片](https://uploader.shimo.im/f/Vdw34YK9xyEEETLO!thumbnail)
通常我们要忽略掉.idea文件夹和以.iml结尾的文件

## 7. 第七步

提交代码

![图片](https://uploader.shimo.im/f/x9338N7Co00fgZuK!thumbnail)
![图片](https://uploader.shimo.im/f/C13alKHyleY3hvfi!thumbnail)

此时代码检查工具会有提示, 直接点击commit即可
![图片](https://uploader.shimo.im/f/qADNYsBPXoE8fVOm!thumbnail)

看到如下提示, 说明提交成功
![图片](https://uploader.shimo.im/f/oodS3INsTnIxPVNf!thumbnail)
# 十四. 使用GIT管理代码

在进行本操作前, 请准备好GIT环境
## 1. 第一步

开启版本控制
![图片](https://uploader.shimo.im/f/KA0eI28iLHQc7ZqR!thumbnail)
## 2. 第二步

选择GIT
![图片](https://uploader.shimo.im/f/gFsDQq0wj9w2PLee!thumbnail)
## 3. 第三步

设置忽略

![图片](https://uploader.shimo.im/f/LQ83oVgdJY0iBACc!thumbnail)

![图片](https://uploader.shimo.im/f/2MZUlWBoKaoSFJ8c!thumbnail)
通常我们要忽略掉.idea文件夹和以.iml结尾的文件
## 4. 第四步

提交代码到本地仓库
![图片](https://uploader.shimo.im/f/Ga9NdnAaP90idUJM!thumbnail)
![图片](https://uploader.shimo.im/f/AsMOqUy3QYMeKn7S!thumbnail)

## 5. 第五步

提交代码到远程仓库
![图片](https://uploader.shimo.im/f/XBFwVB5neNILXQpW!thumbnail)

![图片](https://uploader.shimo.im/f/eKonx56BvU4AAG8n!thumbnail)
![图片](https://uploader.shimo.im/f/lbwEcpLns6o2RCU9!thumbnail)
输入访问远程仓库的用户名和密码
![图片](https://uploader.shimo.im/f/eYxdAP0EYVYueLiv!thumbnail)
输入帐号之后, 如果右下角弹出如下提示, 说明提交成功
![图片](https://uploader.shimo.im/f/GzUxTBm2zq8U8Oxi!thumbnail)


