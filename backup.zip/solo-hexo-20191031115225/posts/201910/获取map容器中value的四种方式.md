title: 获取map容器中value的四种方式
date: '2019-10-23 15:08:06'
updated: '2019-10-23 15:08:06'
tags: [随笔, code]
permalink: /articles/2019/10/23/1571814486704.html
---
获取map容器中value的四种方式
```
	public void testGetMapValue(){
		Map<String, String> map = new HashMap<>(16);
		map.put("a", "1");
		map.put("b", "2");
		map.put("c", "3");
		map.put("d", "4");
		// 1、key确定，取value
		System.out.println("=============key确定==============");
		map.get("a");
		// 2、key不确定
		System.out.println("=============key不确定==============");
		// 2.1、map.keySet()
		getMapValueByKeySet(map);
		// 2.2 iterator迭代器
		getMapValueByIterator(map);
		// 2.3 map.entrySet()
		getMapValueByEntrySet(map);
	}

	private void getMapValueByEntrySet(Map<String, String> map) {
		System.out.println("=============map.entrySet()==============");
		for(Map.Entry<String, String> vo : map.entrySet()){
			System.out.println(vo.getKey()+"  "+vo.getValue());
		}
	}

	private void getMapValueByIterator(Map<String, String> map) {
		System.out.println("=============map.keySet().iterator()==============");
		Iterator<String> iter = map.keySet().iterator();
		while(iter.hasNext()){
			String key=iter.next();
			String value = map.get(key);
			System.out.println(key+" "+value);
		}
	}

	private void getMapValueByKeySet(Map<String, String> map) {
		System.out.println("=============map.keySet()==============");
		for(String key : map.keySet()){
			String value = map.get(key);
			System.out.println(key+"  "+value);
		}
	}
```
